gklearn.kernels.treeletKernel
=============================

.. automodule:: gklearn.kernels.treeletKernel
    :members:
    :undoc-members:
    :show-inheritance:
