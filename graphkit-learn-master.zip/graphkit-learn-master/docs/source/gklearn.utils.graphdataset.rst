gklearn.utils.graphdataset
==========================

.. automodule:: gklearn.utils.graphdataset
    :members:
    :undoc-members:
    :show-inheritance:
