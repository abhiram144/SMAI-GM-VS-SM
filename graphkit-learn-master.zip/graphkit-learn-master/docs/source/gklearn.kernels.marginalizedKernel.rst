gklearn.kernels.marginalizedKernel
==================================

.. automodule:: gklearn.kernels.marginalizedKernel
    :members:
    :undoc-members:
    :show-inheritance:
