gklearn.kernels.structuralspKernel
==================================

.. automodule:: gklearn.kernels.structuralspKernel
    :members:
    :undoc-members:
    :show-inheritance:
