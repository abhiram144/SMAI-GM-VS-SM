gklearn.utils.model\_selection\_precomputed
===========================================

.. automodule:: gklearn.utils.model_selection_precomputed
    :members:
    :undoc-members:
    :show-inheritance:
