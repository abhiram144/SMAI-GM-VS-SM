gklearn.kernels.untilHPathKernel
================================

.. automodule:: gklearn.kernels.untilHPathKernel
    :members:
    :undoc-members:
    :show-inheritance:
