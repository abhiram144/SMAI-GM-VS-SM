gklearn.kernels
===============

.. automodule:: gklearn.kernels
    :members:
    :undoc-members:
    :show-inheritance:

.. toctree::

   gklearn.kernels.commonWalkKernel
   gklearn.kernels.marginalizedKernel
   gklearn.kernels.randomWalkKernel
   gklearn.kernels.spKernel
   gklearn.kernels.structuralspKernel
   gklearn.kernels.treeletKernel
   gklearn.kernels.untilHPathKernel
   gklearn.kernels.weisfeilerLehmanKernel

