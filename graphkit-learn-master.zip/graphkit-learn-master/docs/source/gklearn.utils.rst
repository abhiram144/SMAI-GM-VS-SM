gklearn.utils
=============

.. automodule:: gklearn.utils
    :members:
    :undoc-members:
    :show-inheritance:


.. toctree::

   gklearn.utils.graphdataset
   gklearn.utils.graphfiles
   gklearn.utils.kernels
   gklearn.utils.model_selection_precomputed
   gklearn.utils.parallel
   gklearn.utils.trie
   gklearn.utils.utils

