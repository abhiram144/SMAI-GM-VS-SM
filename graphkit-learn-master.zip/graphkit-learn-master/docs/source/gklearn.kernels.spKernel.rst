gklearn.kernels.spKernel
========================

.. automodule:: gklearn.kernels.spKernel
    :members:
    :undoc-members:
    :show-inheritance:
