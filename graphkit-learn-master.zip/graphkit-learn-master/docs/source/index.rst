.. graphkit-learn documentation master file, created by
   sphinx-quickstart on Wed Feb 12 15:06:37 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. mdinclude:: ../../README.md

Documentation
-------------

.. toctree::
   :maxdepth: 1

   modules.rst
   experiments.rst



Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
