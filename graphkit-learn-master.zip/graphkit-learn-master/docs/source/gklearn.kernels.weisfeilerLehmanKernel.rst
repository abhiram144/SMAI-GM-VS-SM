gklearn.kernels.weisfeilerLehmanKernel
======================================

.. automodule:: gklearn.kernels.weisfeilerLehmanKernel
    :members:
    :undoc-members:
    :show-inheritance:
