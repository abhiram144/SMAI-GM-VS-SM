#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 15 18:22:34 2020

@author: ljia
"""

import os
EXP_ROOT = os.path.dirname(os.path.realpath(__file__)) + '/'
DATASET_ROOT = os.path.dirname(os.path.realpath(__file__)) + '/datasets/'