# Fit Distances

# Run xp:
```
python3 -m pip install graphkit-learn
python3 run_xp.py
```

Plot results in figure and LaTex tables:
```
python3 ged_fit_distance_results_plot.py
``` 

# Run xp (deprecated).
```
export PYTHONPATH="/path/to/gedlibpy:/path/to/py-graph"
python optim_costs.py dataset output_file
```
