# -*-coding:utf-8 -*-
"""
gedlib

"""

# info
__version__ = "0.1"
__author__  = "Linlin Jia"
__date__    = "March 2020"
