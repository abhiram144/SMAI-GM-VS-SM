from gklearn.ged.edit_costs.edit_cost import EditCost
from gklearn.ged.edit_costs.constant import Constant