#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  7 16:07:25 2020

@author: ljia
"""

from gklearn.ged.learning.cost_matrices_learner import CostMatricesLearner