Polyciclic Aromatic Hydrocarbons dataset (PAH) This dataset is composed cyclic unlabeled graphs. All atoms are carbons, all bounds are aromatics. Note that few acyclic bounds connect some atoms to cycles. This is a classification problem (cancerous or not cancerous molecules)

# references
[1] https://brunl01.users.greyc.fr/CHEMISTRY/index.html#PAH
