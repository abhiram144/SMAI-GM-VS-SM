Node attributes:	[x, y]

Class labels were converted to integer values using this map:

	0	Z
	1	N
	2	X
	3	T
	4	W
	5	A
	6	M
	7	K
	8	L
	9	E
	10	H
	11	F
	12	V
	13	I
	14	Y


