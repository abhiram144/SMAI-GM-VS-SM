Node attributes:	[x, y]

Edge attributes:	[orient, angle]

Class labels were converted to integer values using this map:

	0	L 
	1	TR
	2	A 
	3	TA
	4	W 
	5	R 
	6	T 
	7	WR
	8	TL
	9	LT
	10	AT
	11	RT
	12	WL
	13	RW
	14	AR


