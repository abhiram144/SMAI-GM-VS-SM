A database of acyclic molecules with hetero atoms (acyclic ethers, peroxides, acetals and their sulfur analogues). The dataset is concerned with the determination of the boiling point using regression (see dataset.ds) In both results presented bellow GLK stands for graph Laplacian kernel. 

# references
[1] https://brunl01.users.greyc.fr/CHEMISTRY/index.html#Acyclic

**Attention the file dataset_bps.ds is sent to me by Benoit. The original one has some problems and now is renamed dataset_bps_old.ds.**
